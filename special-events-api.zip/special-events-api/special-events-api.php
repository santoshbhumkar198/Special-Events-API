
<?php
/*
Plugin Name: Special Events API
Description: A simple CRUD API for managing special events.
Version: 1.0
Author: Santosh Bhumkar
*/


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

include_once(plugin_dir_path(__FILE__) . 'includes/events-api.php');
include_once(plugin_dir_path(__FILE__) . 'includes/admin-menu.php');
