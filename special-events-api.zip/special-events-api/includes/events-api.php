<?php
function se_register_event_post_type() {
    register_post_type('event', array(
        'labels' => array(
            'name' => __('Events'),
            'singular_name' => __('Event'),
        ),
        'public' => false,
        'show_ui' => false,
        'show_in_menu' => false,
        'supports' => array('title', 'editor'),
        'rewrite' => array('slug' => 'event'),
        'show_in_rest' => true,
        'rest_base' => 'events',
    ));
}
add_action('init', 'se_register_event_post_type');

function se_register_event_routes() {
    register_rest_route('se/v1', '/events/create', array(
        'methods' => 'POST',
        'callback' => 'se_create_event',
        'permission_callback' => 'se_check_permissions',
    ));
    register_rest_route('se/v1', '/events/update', array(
        'methods' => 'POST',
        'callback' => 'se_update_event',
        'permission_callback' => 'se_check_permissions',
    ));
    register_rest_route('se/v1', '/events/list', array(
        'methods' => 'GET',
        'callback' => 'se_list_events',
        'permission_callback' => 'se_check_permissions',
    ));
    register_rest_route('se/v1', '/events/delete', array(
        'methods' => 'DELETE',
        'callback' => 'se_delete_event',
        'permission_callback' => 'se_check_permissions',
    ));
    register_rest_route('se/v1', '/events/show', array(
        'methods' => 'GET',
        'callback' => 'se_show_event',
        'permission_callback' => 'se_check_permissions',
    ));
}
add_action('rest_api_init', 'se_register_event_routes');


function se_check_permissions() {
    return current_user_can('administrator');
}


function se_create_event( $data ) {
    $post_id = wp_insert_post(array(
        'post_type' => 'event',
        'post_title' => sanitize_text_field($data['title']),
        'post_content' => sanitize_textarea_field($data['description']),
        'post_status' => 'publish',
        'meta_input' => array(
            'start_date' => sanitize_text_field($data['start_date']),
            'end_date' => sanitize_text_field($data['end_date']),
            'category' => sanitize_text_field($data['category']),
        ),
    ));
    if ( is_wp_error($post_id) ) {
        return new WP_Error('create_event_failed', 'Failed to create event.', array('status' => 500));
    }
    return array('post_id' => $post_id);
}


function se_update_event( $data ) {
    $post_id = $data['id'];
    $update = wp_update_post(array(
        'ID' => $post_id,
        'post_title' => sanitize_text_field($data['title']),
        'post_content' => sanitize_textarea_field($data['description']),
        'meta_input' => array(
            'start_date' => sanitize_text_field($data['start_date']),
            'end_date' => sanitize_text_field($data['end_date']),
            'category' => sanitize_text_field($data['category']),
        ),
    ));
    if ( is_wp_error($update) ) {
        return new WP_Error('update_event_failed', 'Failed to update event.', array('status' => 500));
    }
    return array('post_id' => $post_id);
}

function se_list_events( $data ) {
    $args = array(
        'post_type' => 'event',
        'post_status' => 'publish',
        'meta_query' => array(),
    );
    if (isset($data['date'])) {
        $args['meta_query'][] = array(
            'key' => 'start_date',
            'value' => sanitize_text_field($data['date']),
            'compare' => '=',
        );
    }
    $query = new WP_Query($args);
    $events = array();
    foreach ($query->posts as $post) {
        $events[] = array(
            'id' => $post->ID,
            'title' => get_the_title($post->ID),
            'start_date' => get_post_meta($post->ID, 'start_date', true),
            'end_date' => get_post_meta($post->ID, 'end_date', true),
            'description' => $post->post_content,
            'category' => get_post_meta($post->ID, 'category', true),
        );
    }
    return $events;
}

function se_show_event( $data ) {
    $post_id = $data['id'];
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'event') {
        return new WP_Error('event_not_found', 'Event not found.', array('status' => 404));
    }
    return array(
        'id' => $post->ID,
        'title' => get_the_title($post->ID),
        'start_date' => get_post_meta($post->ID, 'start_date', true),
        'end_date' => get_post_meta($post->ID, 'end_date', true),
        'description' => $post->post_content,
        'category' => get_post_meta($post->ID, 'category', true),
    );
}

function se_delete_event( $data ) {
    $post_id = $data['id'];
    $result = wp_delete_post($post_id, true);
    if (!$result) {
        return new WP_Error('delete_event_failed', 'Failed to delete event.', array('status' => 500));
    }
    return array('deleted' => true);
}

add_action('admin_post_se_save_event', 'se_handle_save_event');

function se_handle_save_event() {
    if (!current_user_can('administrator') || !isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'se_save_event_action')) {
        wp_die('Not allowed');
    }

    $post_id = wp_insert_post(array(
        'post_type' => 'event',
        'post_title' => sanitize_text_field($_POST['event_title']),
        'post_content' => sanitize_textarea_field($_POST['event_description']),
        'post_status' => 'publish',
        'meta_input' => array(
            'start_date' => sanitize_text_field($_POST['event_start_date']),
            'end_date' => sanitize_text_field($_POST['event_end_date']),
            'category' => sanitize_text_field($_POST['event_category']),
        ),
    ));

    if ( is_wp_error($post_id) ) {
        wp_die('Failed to save event');
    }

    wp_redirect(admin_url('admin.php?page=special-events'));
    exit;
}

add_action('admin_post_se_delete_event', 'se_handle_delete_event');

function se_handle_delete_event() {
    if (!current_user_can('administrator') || !isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'se_delete_event_' . $_GET['id'])) {
        wp_die('Not allowed');
    }

    $post_id = intval($_GET['id']);
    $result = wp_delete_post($post_id, true);

    if (!$result) {
        wp_die('Failed to delete event');
    }

    wp_redirect(admin_url('admin.php?page=special-events'));
    exit;
}

add_action('admin_post_se_update_event', 'se_handle_update_event');

function se_handle_update_event() {
    if (!current_user_can('administrator') || !isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'se_update_event_action')) {
        wp_die('Not allowed');
    }

    $post_id = intval($_POST['event_id']);
    $update = wp_update_post(array(
        'ID' => $post_id,
        'post_title' => sanitize_text_field($_POST['event_title']),
        'post_content' => sanitize_textarea_field($_POST['event_description']),
        'meta_input' => array(
            'start_date' => sanitize_text_field($_POST['event_start_date']),
            'end_date' => sanitize_text_field($_POST['event_end_date']),
            'category' => sanitize_text_field($_POST['event_category']),
        ),
    ));

    if ( is_wp_error($update) ) {
        wp_die('Failed to update event');
    }

    wp_redirect(admin_url('admin.php?page=special-events'));
    exit;
}
?>
