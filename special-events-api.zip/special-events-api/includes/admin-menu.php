<?php

add_action('admin_menu', 'se_add_admin_menu');


function se_add_admin_menu() {
    add_menu_page(
        'Special Events',        // Page title
        'Special Events',        // Menu title
        'manage_options',        // Capability
        'special-events',        // Menu slug
        'se_admin_page',         // Callback function
        'dashicons-calendar',    // Icon
        6                       // Position
    );

    add_submenu_page(
        'special-events',        
        'Add New Event',         
        'Add New Event',         
        'manage_options',        
        'special-events-new',    
        'se_add_new_event_page'  
    );

    add_submenu_page(
        null,                    
        'Edit Event',            
        'Edit Event',           
        'manage_options',        
        'special-events-edit',   
        'se_edit_event_page'     
    );
}

function se_admin_page() {
    $args = array(
        'post_type' => 'event',
        'post_status' => 'publish',
        'posts_per_page' => -1
    );
    $query = new WP_Query($args);
    ?>
    <div class="wrap">
        <h1>Special Events</h1>
        <a href="<?php echo esc_url(admin_url('admin.php?page=special-events-new')); ?>" class="button button-primary">Add New Event</a>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
                    <tr>
                        <td><?php the_title(); ?></td>
                        <td><?php echo get_post_meta(get_the_ID(), 'start_date', true); ?></td>
                        <td><?php echo get_post_meta(get_the_ID(), 'end_date', true); ?></td>
                        <td><?php the_content(); ?></td>
                        <td><?php echo get_post_meta(get_the_ID(), 'category', true); ?></td>
                        <td>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=special-events-edit&post=' . get_the_ID())); ?>">Edit</a> |
                            <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=se_delete_event&id=' . get_the_ID()), 'se_delete_event_' . get_the_ID()); ?>" onclick="return confirm('Are you sure you want to delete this event?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; else : ?>
                    <tr>
                        <td colspan="6">No events found.</td>
                    </tr>
                <?php endif; wp_reset_postdata(); ?>
            </tbody>
        </table>
    </div>
    <?php
}


function se_add_new_event_page() {
    ?>
    <div class="wrap">
        <h1>Add New Event</h1>
        <form method="post" action="admin-post.php">
            <input type="hidden" name="action" value="se_save_event">
            <?php wp_nonce_field('se_save_event_action'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="event_title">Title</label></th>
                    <td><input type="text" id="event_title" name="event_title" class="regular-text" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_start_date">Start Date</label></th>
                    <td><input type="datetime-local" id="event_start_date" name="event_start_date" class="regular-text" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_end_date">End Date</label></th>
                    <td><input type="datetime-local" id="event_end_date" name="event_end_date" class="regular-text" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_description">Description</label></th>
                    <td><textarea id="event_description" name="event_description" class="large-text" rows="5" required></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_category">Category</label></th>
                    <td><input type="text" id="event_category" name="event_category" class="regular-text" required></td>
                </tr>
            </table>
            <?php submit_button('Save Event'); ?>
        </form>
    </div>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            form.addEventListener('submit', function(event) {
                const startDate = document.getElementById('event_start_date').value;
                const endDate = document.getElementById('event_end_date').value;

                if (new Date(startDate) >= new Date(endDate)) {
                    event.preventDefault();
                    alert('The start date must be before the end date.');
                }
            });
        });
    </script>
    <?php
}

function se_edit_event_page() {
    $post_id = intval($_GET['post']);
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'event') {
        echo '<div class="notice notice-error"><p>Event not found.</p></div>';
        return;
    }

    $start_date = get_post_meta($post_id, 'start_date', true);
    $end_date = get_post_meta($post_id, 'end_date', true);
    $category = get_post_meta($post_id, 'category', true);
    ?>
    <div class="wrap">
        <h1>Edit Event</h1>
        <form method="post" action="admin-post.php">
            <input type="hidden" name="action" value="se_update_event">
            <input type="hidden" name="event_id" value="<?php echo esc_attr($post_id); ?>">
            <?php wp_nonce_field('se_update_event_action'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="event_title">Title</label></th>
                    <td><input type="text" id="event_title" name="event_title" class="regular-text" value="<?php echo esc_attr($post->post_title); ?>" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_start_date">Start Date</label></th>
                    <td><input type="datetime-local" id="event_start_date" name="event_start_date" class="regular-text" value="<?php echo esc_attr($start_date); ?>" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_end_date">End Date</label></th>
                    <td><input type="datetime-local" id="event_end_date" name="event_end_date" class="regular-text" value="<?php echo esc_attr($end_date); ?>" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_description">Description</label></th>
                    <td><textarea id="event_description" name="event_description" class="large-text" rows="5" required><?php echo esc_textarea($post->post_content); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="event_category">Category</label></th>
                    <td><input type="text" id="event_category" name="event_category" class="regular-text" value="<?php echo esc_attr($category); ?>" required></td>
                </tr>
            </table>
            <?php submit_button('Update Event'); ?>
        </form>
    </div>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            form.addEventListener('submit', function(event) {
                const startDate = document.getElementById('event_start_date').value;
                const endDate = document.getElementById('event_end_date').value;

                if (new Date(startDate) >= new Date(endDate)) {
                    event.preventDefault();
                    alert('The start date must be before the end date.');
                }
            });
        });
    </script>
    <?php
}

add_action('admin_enqueue_scripts', 'se_enqueue_admin_styles');

function se_enqueue_admin_styles($hook) {
    
    if ($hook == 'toplevel_page_special-events' || $hook == 'special-events_page_special-events-new' || $hook == 'special-events_page_special-events-edit') {
        wp_enqueue_style('se_admin_css', plugin_dir_url(__FILE__) . 'admin-style.css');
    }
}
